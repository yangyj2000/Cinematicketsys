package com.demo.service;

/**
 * 时间: 2017/11/18 11:11
 */

public interface Service {
}
