package com.demo.entity;

/**
 * 时间: 2017/11/19 18:20
 * 功能: 管理员bean
 */

public class Admin {
    public int id;
    public String username;
    public String password;
}
